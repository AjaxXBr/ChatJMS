import jakarta.jms.Connection;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.Destination;
import jakarta.jms.MessageProducer;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;
import org.apache.activemq.ActiveMQConnectionFactory;
import java.util.Scanner;

public class ClienteChat {
    public static void main(String[] args) {
        try {
            String brokerURL = "tcp://localhost:61616";
            ConnectionFactory factory = new ActiveMQConnectionFactory(brokerURL);
            Connection connection = factory.createConnection();
            connection.start();
            

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Destination fila = session.createQueue("CHAT_FILA");

            MessageProducer produtor = session.createProducer(fila);

            Scanner sc = new Scanner(System.in);
            System.out.print("Digite seu código de usuário: ");
            String codigo = sc.nextLine();

            System.out.println("Digite suas mensagens (ou 'sair' para encerrar):");
            while (true) {
                System.out.print("> ");
                String texto = sc.nextLine();
                if (texto.equalsIgnoreCase("sair")) break;

                TextMessage msg = session.createTextMessage(texto);
                msg.setStringProperty("codigoUsuario", codigo);
                produtor.send(msg);
            }

            sc.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
