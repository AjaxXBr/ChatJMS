import jakarta.jms.Connection;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.Destination;
import jakarta.jms.Message;
import jakarta.jms.MessageConsumer;
import jakarta.jms.MessageListener;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;


public class ServidorJMS {
    public static void main(String[] args) {
        try {
            String brokerURL = "tcp://localhost:61616";
            ConnectionFactory factory = new ActiveMQConnectionFactory(brokerURL);
            Connection connection = factory.createConnection();
            connection.start();

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Destination fila = session.createQueue("CHAT_FILA");

            MessageConsumer consumidor = session.createConsumer(fila);

            consumidor.setMessageListener(new MessageListener() {
                public void onMessage(Message mensagem) {
                    try {
                        if (mensagem instanceof TextMessage) {
                            TextMessage txt = (TextMessage) mensagem;
                            String remetente = txt.getStringProperty("codigoUsuario");
                            System.out.println(remetente + ": " + txt.getText());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

            System.out.println("Servidor ativo. Aguardando mensagens...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
